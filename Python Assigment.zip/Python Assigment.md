```python
## Exploratory Data Anaylysis on Las Vegas TripAdvisor Reviews

import numpy as np
import pandas as pd

import seaborn as sns
import matplotlib.pyplot as plt


```


```python
# load and read data file

lasvegas_data = pd.read_csv(r'D:\Data Analytics\Python\LasVegasTripAdvisorReviews-Dataset.csv')
lasvegas_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>Total Reviews</th>
      <th>Hotel Reviews</th>
      <th>Helpful Votes</th>
      <th>Rating</th>
      <th>Stay Period</th>
      <th>Traveler Type</th>
      <th>Has Pool</th>
      <th>Has Gym</th>
      <th>Has Tennis Court</th>
      <th>Has Spa</th>
      <th>Has Casino</th>
      <th>Has Free Internet</th>
      <th>Hotel Name</th>
      <th>Hotel Stars</th>
      <th>Hotel Rooms</th>
      <th>Continent</th>
      <th>Membership Years</th>
      <th>Review Month</th>
      <th>Review weekday,</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>USA</td>
      <td>11</td>
      <td>4</td>
      <td>13</td>
      <td>5</td>
      <td>Dec-Feb</td>
      <td>Friends</td>
      <td>NO</td>
      <td>YES</td>
      <td>NO</td>
      <td>NO</td>
      <td>YES</td>
      <td>YES</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>9</td>
      <td>January</td>
      <td>Thursday,</td>
    </tr>
    <tr>
      <th>1</th>
      <td>USA</td>
      <td>119</td>
      <td>21</td>
      <td>75</td>
      <td>3</td>
      <td>Dec-Feb</td>
      <td>Business</td>
      <td>NO</td>
      <td>YES</td>
      <td>NO</td>
      <td>NO</td>
      <td>YES</td>
      <td>YES</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>3</td>
      <td>January</td>
      <td>Friday,</td>
    </tr>
    <tr>
      <th>2</th>
      <td>USA</td>
      <td>36</td>
      <td>9</td>
      <td>25</td>
      <td>5</td>
      <td>Mar-May</td>
      <td>Families</td>
      <td>NO</td>
      <td>YES</td>
      <td>NO</td>
      <td>NO</td>
      <td>YES</td>
      <td>YES</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>2</td>
      <td>February</td>
      <td>Saturday,</td>
    </tr>
    <tr>
      <th>3</th>
      <td>UK</td>
      <td>14</td>
      <td>7</td>
      <td>14</td>
      <td>4</td>
      <td>Mar-May</td>
      <td>Friends</td>
      <td>NO</td>
      <td>YES</td>
      <td>NO</td>
      <td>NO</td>
      <td>YES</td>
      <td>YES</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>Europe</td>
      <td>6</td>
      <td>February</td>
      <td>Friday,</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Canada</td>
      <td>5</td>
      <td>5</td>
      <td>2</td>
      <td>4</td>
      <td>Mar-May</td>
      <td>Solo</td>
      <td>NO</td>
      <td>YES</td>
      <td>NO</td>
      <td>NO</td>
      <td>YES</td>
      <td>YES</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>7</td>
      <td>March</td>
      <td>Tuesday,</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>499</th>
      <td>UK</td>
      <td>15</td>
      <td>4</td>
      <td>8</td>
      <td>5</td>
      <td>Sep-Nov</td>
      <td>Couples</td>
      <td>YES</td>
      <td>YES</td>
      <td>NO</td>
      <td>YES</td>
      <td>YES</td>
      <td>YES</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>Europe</td>
      <td>1</td>
      <td>October</td>
      <td>Sunday,</td>
    </tr>
    <tr>
      <th>500</th>
      <td>Canada</td>
      <td>50</td>
      <td>13</td>
      <td>29</td>
      <td>4</td>
      <td>Sep-Nov</td>
      <td>Couples</td>
      <td>YES</td>
      <td>YES</td>
      <td>NO</td>
      <td>YES</td>
      <td>YES</td>
      <td>YES</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>8</td>
      <td>November</td>
      <td>Thursday,</td>
    </tr>
    <tr>
      <th>501</th>
      <td>USA</td>
      <td>154</td>
      <td>23</td>
      <td>31</td>
      <td>4</td>
      <td>Sep-Nov</td>
      <td>Friends</td>
      <td>YES</td>
      <td>YES</td>
      <td>NO</td>
      <td>YES</td>
      <td>YES</td>
      <td>YES</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>4</td>
      <td>November</td>
      <td>Thursday,</td>
    </tr>
    <tr>
      <th>502</th>
      <td>USA</td>
      <td>9</td>
      <td>6</td>
      <td>5</td>
      <td>2</td>
      <td>Dec-Feb</td>
      <td>Families</td>
      <td>YES</td>
      <td>YES</td>
      <td>NO</td>
      <td>YES</td>
      <td>YES</td>
      <td>YES</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>9</td>
      <td>December</td>
      <td>Wednesday,</td>
    </tr>
    <tr>
      <th>503</th>
      <td>USA</td>
      <td>20</td>
      <td>19</td>
      <td>112</td>
      <td>4</td>
      <td>Dec-Feb</td>
      <td>Families</td>
      <td>YES</td>
      <td>YES</td>
      <td>NO</td>
      <td>YES</td>
      <td>YES</td>
      <td>YES</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>5</td>
      <td>December</td>
      <td>Tuesday,</td>
    </tr>
  </tbody>
</table>
<p>504 rows × 20 columns</p>
</div>




```python
lasvegas_data1 = lasvegas_data.replace("YES","1",limit =200)
lasvegas_data1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>Total Reviews</th>
      <th>Hotel Reviews</th>
      <th>Helpful Votes</th>
      <th>Rating</th>
      <th>Stay Period</th>
      <th>Traveler Type</th>
      <th>Has Pool</th>
      <th>Has Gym</th>
      <th>Has Tennis Court</th>
      <th>Has Spa</th>
      <th>Has Casino</th>
      <th>Has Free Internet</th>
      <th>Hotel Name</th>
      <th>Hotel Stars</th>
      <th>Hotel Rooms</th>
      <th>Continent</th>
      <th>Membership Years</th>
      <th>Review Month</th>
      <th>Review weekday,</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>USA</td>
      <td>11</td>
      <td>4</td>
      <td>13</td>
      <td>5</td>
      <td>Dec-Feb</td>
      <td>Friends</td>
      <td>NO</td>
      <td>1</td>
      <td>NO</td>
      <td>NO</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>9</td>
      <td>January</td>
      <td>Thursday,</td>
    </tr>
    <tr>
      <th>1</th>
      <td>USA</td>
      <td>119</td>
      <td>21</td>
      <td>75</td>
      <td>3</td>
      <td>Dec-Feb</td>
      <td>Business</td>
      <td>NO</td>
      <td>1</td>
      <td>NO</td>
      <td>NO</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>3</td>
      <td>January</td>
      <td>Friday,</td>
    </tr>
    <tr>
      <th>2</th>
      <td>USA</td>
      <td>36</td>
      <td>9</td>
      <td>25</td>
      <td>5</td>
      <td>Mar-May</td>
      <td>Families</td>
      <td>NO</td>
      <td>1</td>
      <td>NO</td>
      <td>NO</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>2</td>
      <td>February</td>
      <td>Saturday,</td>
    </tr>
    <tr>
      <th>3</th>
      <td>UK</td>
      <td>14</td>
      <td>7</td>
      <td>14</td>
      <td>4</td>
      <td>Mar-May</td>
      <td>Friends</td>
      <td>NO</td>
      <td>1</td>
      <td>NO</td>
      <td>NO</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>Europe</td>
      <td>6</td>
      <td>February</td>
      <td>Friday,</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Canada</td>
      <td>5</td>
      <td>5</td>
      <td>2</td>
      <td>4</td>
      <td>Mar-May</td>
      <td>Solo</td>
      <td>NO</td>
      <td>1</td>
      <td>NO</td>
      <td>NO</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>7</td>
      <td>March</td>
      <td>Tuesday,</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>499</th>
      <td>UK</td>
      <td>15</td>
      <td>4</td>
      <td>8</td>
      <td>5</td>
      <td>Sep-Nov</td>
      <td>Couples</td>
      <td>1</td>
      <td>1</td>
      <td>NO</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>Europe</td>
      <td>1</td>
      <td>October</td>
      <td>Sunday,</td>
    </tr>
    <tr>
      <th>500</th>
      <td>Canada</td>
      <td>50</td>
      <td>13</td>
      <td>29</td>
      <td>4</td>
      <td>Sep-Nov</td>
      <td>Couples</td>
      <td>1</td>
      <td>1</td>
      <td>NO</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>8</td>
      <td>November</td>
      <td>Thursday,</td>
    </tr>
    <tr>
      <th>501</th>
      <td>USA</td>
      <td>154</td>
      <td>23</td>
      <td>31</td>
      <td>4</td>
      <td>Sep-Nov</td>
      <td>Friends</td>
      <td>1</td>
      <td>1</td>
      <td>NO</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>4</td>
      <td>November</td>
      <td>Thursday,</td>
    </tr>
    <tr>
      <th>502</th>
      <td>USA</td>
      <td>9</td>
      <td>6</td>
      <td>5</td>
      <td>2</td>
      <td>Dec-Feb</td>
      <td>Families</td>
      <td>1</td>
      <td>1</td>
      <td>NO</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>9</td>
      <td>December</td>
      <td>Wednesday,</td>
    </tr>
    <tr>
      <th>503</th>
      <td>USA</td>
      <td>20</td>
      <td>19</td>
      <td>112</td>
      <td>4</td>
      <td>Dec-Feb</td>
      <td>Families</td>
      <td>1</td>
      <td>1</td>
      <td>NO</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>5</td>
      <td>December</td>
      <td>Tuesday,</td>
    </tr>
  </tbody>
</table>
<p>504 rows × 20 columns</p>
</div>




```python
lasvegas_data = lasvegas_data1.replace("NO","0",limit =200)
lasvegas_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>Total Reviews</th>
      <th>Hotel Reviews</th>
      <th>Helpful Votes</th>
      <th>Rating</th>
      <th>Stay Period</th>
      <th>Traveler Type</th>
      <th>Has Pool</th>
      <th>Has Gym</th>
      <th>Has Tennis Court</th>
      <th>Has Spa</th>
      <th>Has Casino</th>
      <th>Has Free Internet</th>
      <th>Hotel Name</th>
      <th>Hotel Stars</th>
      <th>Hotel Rooms</th>
      <th>Continent</th>
      <th>Membership Years</th>
      <th>Review Month</th>
      <th>Review weekday,</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>USA</td>
      <td>11</td>
      <td>4</td>
      <td>13</td>
      <td>5</td>
      <td>Dec-Feb</td>
      <td>Friends</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>9</td>
      <td>January</td>
      <td>Thursday,</td>
    </tr>
    <tr>
      <th>1</th>
      <td>USA</td>
      <td>119</td>
      <td>21</td>
      <td>75</td>
      <td>3</td>
      <td>Dec-Feb</td>
      <td>Business</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>3</td>
      <td>January</td>
      <td>Friday,</td>
    </tr>
    <tr>
      <th>2</th>
      <td>USA</td>
      <td>36</td>
      <td>9</td>
      <td>25</td>
      <td>5</td>
      <td>Mar-May</td>
      <td>Families</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>2</td>
      <td>February</td>
      <td>Saturday,</td>
    </tr>
    <tr>
      <th>3</th>
      <td>UK</td>
      <td>14</td>
      <td>7</td>
      <td>14</td>
      <td>4</td>
      <td>Mar-May</td>
      <td>Friends</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>Europe</td>
      <td>6</td>
      <td>February</td>
      <td>Friday,</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Canada</td>
      <td>5</td>
      <td>5</td>
      <td>2</td>
      <td>4</td>
      <td>Mar-May</td>
      <td>Solo</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>7</td>
      <td>March</td>
      <td>Tuesday,</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>499</th>
      <td>UK</td>
      <td>15</td>
      <td>4</td>
      <td>8</td>
      <td>5</td>
      <td>Sep-Nov</td>
      <td>Couples</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>Europe</td>
      <td>1</td>
      <td>October</td>
      <td>Sunday,</td>
    </tr>
    <tr>
      <th>500</th>
      <td>Canada</td>
      <td>50</td>
      <td>13</td>
      <td>29</td>
      <td>4</td>
      <td>Sep-Nov</td>
      <td>Couples</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>8</td>
      <td>November</td>
      <td>Thursday,</td>
    </tr>
    <tr>
      <th>501</th>
      <td>USA</td>
      <td>154</td>
      <td>23</td>
      <td>31</td>
      <td>4</td>
      <td>Sep-Nov</td>
      <td>Friends</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>4</td>
      <td>November</td>
      <td>Thursday,</td>
    </tr>
    <tr>
      <th>502</th>
      <td>USA</td>
      <td>9</td>
      <td>6</td>
      <td>5</td>
      <td>2</td>
      <td>Dec-Feb</td>
      <td>Families</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>9</td>
      <td>December</td>
      <td>Wednesday,</td>
    </tr>
    <tr>
      <th>503</th>
      <td>USA</td>
      <td>20</td>
      <td>19</td>
      <td>112</td>
      <td>4</td>
      <td>Dec-Feb</td>
      <td>Families</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>5</td>
      <td>December</td>
      <td>Tuesday,</td>
    </tr>
  </tbody>
</table>
<p>504 rows × 20 columns</p>
</div>




```python
# Data backup
lasvegas_data_backup = lasvegas_data.copy()

# Replacing negative values with zero
lasvegas_data['Membership Years'] = lasvegas_data['Membership Years'].apply(lambda x: x if x >= 0 else 0)
lasvegas_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>Total Reviews</th>
      <th>Hotel Reviews</th>
      <th>Helpful Votes</th>
      <th>Rating</th>
      <th>Stay Period</th>
      <th>Traveler Type</th>
      <th>Has Pool</th>
      <th>Has Gym</th>
      <th>Has Tennis Court</th>
      <th>Has Spa</th>
      <th>Has Casino</th>
      <th>Has Free Internet</th>
      <th>Hotel Name</th>
      <th>Hotel Stars</th>
      <th>Hotel Rooms</th>
      <th>Continent</th>
      <th>Membership Years</th>
      <th>Review Month</th>
      <th>Review weekday,</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>USA</td>
      <td>11</td>
      <td>4</td>
      <td>13</td>
      <td>5</td>
      <td>Dec-Feb</td>
      <td>Friends</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>9</td>
      <td>January</td>
      <td>Thursday,</td>
    </tr>
    <tr>
      <th>1</th>
      <td>USA</td>
      <td>119</td>
      <td>21</td>
      <td>75</td>
      <td>3</td>
      <td>Dec-Feb</td>
      <td>Business</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>3</td>
      <td>January</td>
      <td>Friday,</td>
    </tr>
    <tr>
      <th>2</th>
      <td>USA</td>
      <td>36</td>
      <td>9</td>
      <td>25</td>
      <td>5</td>
      <td>Mar-May</td>
      <td>Families</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>2</td>
      <td>February</td>
      <td>Saturday,</td>
    </tr>
    <tr>
      <th>3</th>
      <td>UK</td>
      <td>14</td>
      <td>7</td>
      <td>14</td>
      <td>4</td>
      <td>Mar-May</td>
      <td>Friends</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>Europe</td>
      <td>6</td>
      <td>February</td>
      <td>Friday,</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Canada</td>
      <td>5</td>
      <td>5</td>
      <td>2</td>
      <td>4</td>
      <td>Mar-May</td>
      <td>Solo</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>7</td>
      <td>March</td>
      <td>Tuesday,</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>499</th>
      <td>UK</td>
      <td>15</td>
      <td>4</td>
      <td>8</td>
      <td>5</td>
      <td>Sep-Nov</td>
      <td>Couples</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>Europe</td>
      <td>1</td>
      <td>October</td>
      <td>Sunday,</td>
    </tr>
    <tr>
      <th>500</th>
      <td>Canada</td>
      <td>50</td>
      <td>13</td>
      <td>29</td>
      <td>4</td>
      <td>Sep-Nov</td>
      <td>Couples</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>8</td>
      <td>November</td>
      <td>Thursday,</td>
    </tr>
    <tr>
      <th>501</th>
      <td>USA</td>
      <td>154</td>
      <td>23</td>
      <td>31</td>
      <td>4</td>
      <td>Sep-Nov</td>
      <td>Friends</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>4</td>
      <td>November</td>
      <td>Thursday,</td>
    </tr>
    <tr>
      <th>502</th>
      <td>USA</td>
      <td>9</td>
      <td>6</td>
      <td>5</td>
      <td>2</td>
      <td>Dec-Feb</td>
      <td>Families</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>9</td>
      <td>December</td>
      <td>Wednesday,</td>
    </tr>
    <tr>
      <th>503</th>
      <td>USA</td>
      <td>20</td>
      <td>19</td>
      <td>112</td>
      <td>4</td>
      <td>Dec-Feb</td>
      <td>Families</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>5</td>
      <td>December</td>
      <td>Tuesday,</td>
    </tr>
  </tbody>
</table>
<p>504 rows × 20 columns</p>
</div>




```python
# Spliting rows with 2 hotel star values into 2 different rows

# Split the 'hotel_star' column by comma and create separate rows for each rating
split_rows = lasvegas_data.assign(hotel_star=lasvegas_data['Hotel Stars'].str.split(','))

# Explode the split rows to create multiple rows
expanded_rows = split_rows.explode('hotel_star').reset_index(drop=True)

# Print the resulting DataFrame
print(expanded_rows)
```

        Country  Total Reviews  Hotel Reviews  Helpful Votes  Rating Stay Period  \
    0       USA             11              4             13       5     Dec-Feb   
    1       USA            119             21             75       3     Dec-Feb   
    2       USA             36              9             25       5     Mar-May   
    3        UK             14              7             14       4     Mar-May   
    4    Canada              5              5              2       4     Mar-May   
    ..      ...            ...            ...            ...     ...         ...   
    595      UK             15              4              8       5     Sep-Nov   
    596  Canada             50             13             29       4     Sep-Nov   
    597     USA            154             23             31       4     Sep-Nov   
    598     USA              9              6              5       2     Dec-Feb   
    599     USA             20             19            112       4     Dec-Feb   
    
        Traveler Type Has Pool Has Gym Has Tennis Court  ... Has Casino  \
    0         Friends        0       1                0  ...          1   
    1        Business        0       1                0  ...          1   
    2        Families        0       1                0  ...          1   
    3         Friends        0       1                0  ...          1   
    4            Solo        0       1                0  ...          1   
    ..            ...      ...     ...              ...  ...        ...   
    595       Couples        1       1                0  ...          1   
    596       Couples        1       1                0  ...          1   
    597       Friends        1       1                0  ...          1   
    598      Families        1       1                0  ...          1   
    599      Families        1       1                0  ...          1   
    
         Has Free Internet                               Hotel Name Hotel Stars  \
    0                    1   Circus Circus Hotel & Casino Las Vegas           3   
    1                    1   Circus Circus Hotel & Casino Las Vegas           3   
    2                    1   Circus Circus Hotel & Casino Las Vegas           3   
    3                    1   Circus Circus Hotel & Casino Las Vegas           3   
    4                    1   Circus Circus Hotel & Casino Las Vegas           3   
    ..                 ...                                      ...         ...   
    595                  1  The Westin las Vegas Hotel Casino & Spa           4   
    596                  1  The Westin las Vegas Hotel Casino & Spa           4   
    597                  1  The Westin las Vegas Hotel Casino & Spa           4   
    598                  1  The Westin las Vegas Hotel Casino & Spa           4   
    599                  1  The Westin las Vegas Hotel Casino & Spa           4   
    
        Hotel Rooms      Continent Membership Years  Review Month Review weekday,  \
    0          3773  North America                9       January       Thursday,   
    1          3773  North America                3       January         Friday,   
    2          3773  North America                2      February       Saturday,   
    3          3773         Europe                6      February         Friday,   
    4          3773  North America                7         March        Tuesday,   
    ..          ...            ...              ...           ...             ...   
    595         826         Europe                1       October         Sunday,   
    596         826  North America                8      November       Thursday,   
    597         826  North America                4      November       Thursday,   
    598         826  North America                9      December      Wednesday,   
    599         826  North America                5      December        Tuesday,   
    
        hotel_star  
    0            3  
    1            3  
    2            3  
    3            3  
    4            3  
    ..         ...  
    595          4  
    596          4  
    597          4  
    598          4  
    599          4  
    
    [600 rows x 21 columns]
    


```python
# Changing name from expanded rows to lasvegas_data
lasvegas_data = expanded_rows
lasvegas_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>Total Reviews</th>
      <th>Hotel Reviews</th>
      <th>Helpful Votes</th>
      <th>Rating</th>
      <th>Stay Period</th>
      <th>Traveler Type</th>
      <th>Has Pool</th>
      <th>Has Gym</th>
      <th>Has Tennis Court</th>
      <th>...</th>
      <th>Has Casino</th>
      <th>Has Free Internet</th>
      <th>Hotel Name</th>
      <th>Hotel Stars</th>
      <th>Hotel Rooms</th>
      <th>Continent</th>
      <th>Membership Years</th>
      <th>Review Month</th>
      <th>Review weekday,</th>
      <th>hotel_star</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>USA</td>
      <td>11</td>
      <td>4</td>
      <td>13</td>
      <td>5</td>
      <td>Dec-Feb</td>
      <td>Friends</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>9</td>
      <td>January</td>
      <td>Thursday,</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1</th>
      <td>USA</td>
      <td>119</td>
      <td>21</td>
      <td>75</td>
      <td>3</td>
      <td>Dec-Feb</td>
      <td>Business</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>3</td>
      <td>January</td>
      <td>Friday,</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>USA</td>
      <td>36</td>
      <td>9</td>
      <td>25</td>
      <td>5</td>
      <td>Mar-May</td>
      <td>Families</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>2</td>
      <td>February</td>
      <td>Saturday,</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>UK</td>
      <td>14</td>
      <td>7</td>
      <td>14</td>
      <td>4</td>
      <td>Mar-May</td>
      <td>Friends</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>Europe</td>
      <td>6</td>
      <td>February</td>
      <td>Friday,</td>
      <td>3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Canada</td>
      <td>5</td>
      <td>5</td>
      <td>2</td>
      <td>4</td>
      <td>Mar-May</td>
      <td>Solo</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>7</td>
      <td>March</td>
      <td>Tuesday,</td>
      <td>3</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>595</th>
      <td>UK</td>
      <td>15</td>
      <td>4</td>
      <td>8</td>
      <td>5</td>
      <td>Sep-Nov</td>
      <td>Couples</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>Europe</td>
      <td>1</td>
      <td>October</td>
      <td>Sunday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>596</th>
      <td>Canada</td>
      <td>50</td>
      <td>13</td>
      <td>29</td>
      <td>4</td>
      <td>Sep-Nov</td>
      <td>Couples</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>8</td>
      <td>November</td>
      <td>Thursday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>597</th>
      <td>USA</td>
      <td>154</td>
      <td>23</td>
      <td>31</td>
      <td>4</td>
      <td>Sep-Nov</td>
      <td>Friends</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>4</td>
      <td>November</td>
      <td>Thursday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>598</th>
      <td>USA</td>
      <td>9</td>
      <td>6</td>
      <td>5</td>
      <td>2</td>
      <td>Dec-Feb</td>
      <td>Families</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>9</td>
      <td>December</td>
      <td>Wednesday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>599</th>
      <td>USA</td>
      <td>20</td>
      <td>19</td>
      <td>112</td>
      <td>4</td>
      <td>Dec-Feb</td>
      <td>Families</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>5</td>
      <td>December</td>
      <td>Tuesday,</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
<p>600 rows × 21 columns</p>
</div>




```python
# Filter records with the specified hotel name
filtered_data = lasvegas_data[lasvegas_data['Hotel Name'] == 'Treasure Island- TI Hotel & Casino']
filtered_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>Total Reviews</th>
      <th>Hotel Reviews</th>
      <th>Helpful Votes</th>
      <th>Rating</th>
      <th>Stay Period</th>
      <th>Traveler Type</th>
      <th>Has Pool</th>
      <th>Has Gym</th>
      <th>Has Tennis Court</th>
      <th>...</th>
      <th>Has Casino</th>
      <th>Has Free Internet</th>
      <th>Hotel Name</th>
      <th>Hotel Stars</th>
      <th>Hotel Rooms</th>
      <th>Continent</th>
      <th>Membership Years</th>
      <th>Review Month</th>
      <th>Review weekday,</th>
      <th>hotel_star</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>72</th>
      <td>Croatia</td>
      <td>29</td>
      <td>11</td>
      <td>14</td>
      <td>3</td>
      <td>Dec-Feb</td>
      <td>Business</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>Europe</td>
      <td>6</td>
      <td>January</td>
      <td>Sunday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>73</th>
      <td>Australia</td>
      <td>11</td>
      <td>5</td>
      <td>8</td>
      <td>4</td>
      <td>Dec-Feb</td>
      <td>Couples</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>Oceania</td>
      <td>1</td>
      <td>January</td>
      <td>Thursday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>74</th>
      <td>Canada</td>
      <td>19</td>
      <td>12</td>
      <td>167</td>
      <td>4</td>
      <td>Dec-Feb</td>
      <td>Friends</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>North America</td>
      <td>9</td>
      <td>February</td>
      <td>Monday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>75</th>
      <td>USA</td>
      <td>17</td>
      <td>9</td>
      <td>16</td>
      <td>5</td>
      <td>Dec-Feb</td>
      <td>Solo</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>North America</td>
      <td>0</td>
      <td>February</td>
      <td>Monday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>76</th>
      <td>USA</td>
      <td>43</td>
      <td>8</td>
      <td>20</td>
      <td>4</td>
      <td>Mar-May</td>
      <td>Couples</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>North America</td>
      <td>1</td>
      <td>March</td>
      <td>Friday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>77</th>
      <td>Canada</td>
      <td>12</td>
      <td>8</td>
      <td>3</td>
      <td>4</td>
      <td>Mar-May</td>
      <td>Friends</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>North America</td>
      <td>2</td>
      <td>March</td>
      <td>Saturday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>78</th>
      <td>USA</td>
      <td>15</td>
      <td>14</td>
      <td>7</td>
      <td>4</td>
      <td>Mar-May</td>
      <td>Friends</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>North America</td>
      <td>9</td>
      <td>April</td>
      <td>Tuesday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>79</th>
      <td>Australia</td>
      <td>16</td>
      <td>13</td>
      <td>16</td>
      <td>3</td>
      <td>Mar-May</td>
      <td>Families</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>Oceania</td>
      <td>6</td>
      <td>April</td>
      <td>Wednesday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>80</th>
      <td>India</td>
      <td>12</td>
      <td>4</td>
      <td>25</td>
      <td>3</td>
      <td>Mar-May</td>
      <td>Families</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>Asia</td>
      <td>1</td>
      <td>May</td>
      <td>Friday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>81</th>
      <td>Germany</td>
      <td>10</td>
      <td>0</td>
      <td>5</td>
      <td>4</td>
      <td>Mar-May</td>
      <td>Friends</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>Europe</td>
      <td>3</td>
      <td>May</td>
      <td>Sunday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>82</th>
      <td>USA</td>
      <td>27</td>
      <td>17</td>
      <td>16</td>
      <td>3</td>
      <td>Jun-Aug</td>
      <td>Families</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>North America</td>
      <td>6</td>
      <td>June</td>
      <td>Thursday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>83</th>
      <td>Canada</td>
      <td>6</td>
      <td>5</td>
      <td>5</td>
      <td>4</td>
      <td>Jun-Aug</td>
      <td>Couples</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>North America</td>
      <td>2</td>
      <td>June</td>
      <td>Tuesday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>84</th>
      <td>Australia</td>
      <td>21</td>
      <td>20</td>
      <td>14</td>
      <td>5</td>
      <td>Jun-Aug</td>
      <td>Couples</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>Oceania</td>
      <td>3</td>
      <td>July</td>
      <td>Wednesday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>85</th>
      <td>Malaysia</td>
      <td>43</td>
      <td>14</td>
      <td>27</td>
      <td>4</td>
      <td>Jun-Aug</td>
      <td>Solo</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>Asia</td>
      <td>5</td>
      <td>July</td>
      <td>Thursday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>86</th>
      <td>Mexico</td>
      <td>97</td>
      <td>31</td>
      <td>37</td>
      <td>4</td>
      <td>Jun-Aug</td>
      <td>Couples</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>South America</td>
      <td>8</td>
      <td>August</td>
      <td>Saturday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>87</th>
      <td>UK</td>
      <td>7</td>
      <td>3</td>
      <td>4</td>
      <td>4</td>
      <td>Jun-Aug</td>
      <td>Couples</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>Europe</td>
      <td>5</td>
      <td>August</td>
      <td>Friday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>88</th>
      <td>UK</td>
      <td>11</td>
      <td>9</td>
      <td>6</td>
      <td>3</td>
      <td>Sep-Nov</td>
      <td>Couples</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>Europe</td>
      <td>0</td>
      <td>September</td>
      <td>Friday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>89</th>
      <td>USA</td>
      <td>78</td>
      <td>11</td>
      <td>30</td>
      <td>4</td>
      <td>Sep-Nov</td>
      <td>Business</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>North America</td>
      <td>2</td>
      <td>September</td>
      <td>Tuesday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>90</th>
      <td>Australia</td>
      <td>12</td>
      <td>7</td>
      <td>4</td>
      <td>5</td>
      <td>Sep-Nov</td>
      <td>Families</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>Oceania</td>
      <td>5</td>
      <td>October</td>
      <td>Monday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>91</th>
      <td>USA</td>
      <td>27</td>
      <td>11</td>
      <td>5</td>
      <td>3</td>
      <td>Sep-Nov</td>
      <td>Couples</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>North America</td>
      <td>2</td>
      <td>October</td>
      <td>Monday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>92</th>
      <td>Thailand</td>
      <td>4</td>
      <td>3</td>
      <td>1</td>
      <td>5</td>
      <td>Sep-Nov</td>
      <td>Couples</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>Asia</td>
      <td>7</td>
      <td>November</td>
      <td>Friday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>93</th>
      <td>Australia</td>
      <td>27</td>
      <td>9</td>
      <td>8</td>
      <td>4</td>
      <td>Sep-Nov</td>
      <td>Families</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>Oceania</td>
      <td>2</td>
      <td>November</td>
      <td>Friday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>94</th>
      <td>Canada</td>
      <td>12</td>
      <td>3</td>
      <td>7</td>
      <td>4</td>
      <td>Dec-Feb</td>
      <td>Friends</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>North America</td>
      <td>4</td>
      <td>December</td>
      <td>Saturday,</td>
      <td>4</td>
    </tr>
    <tr>
      <th>95</th>
      <td>Canada</td>
      <td>21</td>
      <td>16</td>
      <td>48</td>
      <td>5</td>
      <td>Dec-Feb</td>
      <td>Couples</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>4</td>
      <td>2884</td>
      <td>North America</td>
      <td>12</td>
      <td>December</td>
      <td>Thursday,</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
<p>24 rows × 21 columns</p>
</div>




```python
# Restoring backup data removing spliting change

lasvegas_data = lasvegas_data_backup
lasvegas_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>Total Reviews</th>
      <th>Hotel Reviews</th>
      <th>Helpful Votes</th>
      <th>Rating</th>
      <th>Stay Period</th>
      <th>Traveler Type</th>
      <th>Has Pool</th>
      <th>Has Gym</th>
      <th>Has Tennis Court</th>
      <th>Has Spa</th>
      <th>Has Casino</th>
      <th>Has Free Internet</th>
      <th>Hotel Name</th>
      <th>Hotel Stars</th>
      <th>Hotel Rooms</th>
      <th>Continent</th>
      <th>Membership Years</th>
      <th>Review Month</th>
      <th>Review weekday,</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>USA</td>
      <td>11</td>
      <td>4</td>
      <td>13</td>
      <td>5</td>
      <td>Dec-Feb</td>
      <td>Friends</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>9</td>
      <td>January</td>
      <td>Thursday,</td>
    </tr>
    <tr>
      <th>1</th>
      <td>USA</td>
      <td>119</td>
      <td>21</td>
      <td>75</td>
      <td>3</td>
      <td>Dec-Feb</td>
      <td>Business</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>3</td>
      <td>January</td>
      <td>Friday,</td>
    </tr>
    <tr>
      <th>2</th>
      <td>USA</td>
      <td>36</td>
      <td>9</td>
      <td>25</td>
      <td>5</td>
      <td>Mar-May</td>
      <td>Families</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>2</td>
      <td>February</td>
      <td>Saturday,</td>
    </tr>
    <tr>
      <th>3</th>
      <td>UK</td>
      <td>14</td>
      <td>7</td>
      <td>14</td>
      <td>4</td>
      <td>Mar-May</td>
      <td>Friends</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>Europe</td>
      <td>6</td>
      <td>February</td>
      <td>Friday,</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Canada</td>
      <td>5</td>
      <td>5</td>
      <td>2</td>
      <td>4</td>
      <td>Mar-May</td>
      <td>Solo</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>7</td>
      <td>March</td>
      <td>Tuesday,</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>499</th>
      <td>UK</td>
      <td>15</td>
      <td>4</td>
      <td>8</td>
      <td>5</td>
      <td>Sep-Nov</td>
      <td>Couples</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>Europe</td>
      <td>1</td>
      <td>October</td>
      <td>Sunday,</td>
    </tr>
    <tr>
      <th>500</th>
      <td>Canada</td>
      <td>50</td>
      <td>13</td>
      <td>29</td>
      <td>4</td>
      <td>Sep-Nov</td>
      <td>Couples</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>8</td>
      <td>November</td>
      <td>Thursday,</td>
    </tr>
    <tr>
      <th>501</th>
      <td>USA</td>
      <td>154</td>
      <td>23</td>
      <td>31</td>
      <td>4</td>
      <td>Sep-Nov</td>
      <td>Friends</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>4</td>
      <td>November</td>
      <td>Thursday,</td>
    </tr>
    <tr>
      <th>502</th>
      <td>USA</td>
      <td>9</td>
      <td>6</td>
      <td>5</td>
      <td>2</td>
      <td>Dec-Feb</td>
      <td>Families</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>9</td>
      <td>December</td>
      <td>Wednesday,</td>
    </tr>
    <tr>
      <th>503</th>
      <td>USA</td>
      <td>20</td>
      <td>19</td>
      <td>112</td>
      <td>4</td>
      <td>Dec-Feb</td>
      <td>Families</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>5</td>
      <td>December</td>
      <td>Tuesday,</td>
    </tr>
  </tbody>
</table>
<p>504 rows × 20 columns</p>
</div>




```python
# Replacing negative values with zero
lasvegas_data['Membership Years'] = lasvegas_data['Membership Years'].apply(lambda x: x if x >= 0 else 0)
lasvegas_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>Total Reviews</th>
      <th>Hotel Reviews</th>
      <th>Helpful Votes</th>
      <th>Rating</th>
      <th>Stay Period</th>
      <th>Traveler Type</th>
      <th>Has Pool</th>
      <th>Has Gym</th>
      <th>Has Tennis Court</th>
      <th>Has Spa</th>
      <th>Has Casino</th>
      <th>Has Free Internet</th>
      <th>Hotel Name</th>
      <th>Hotel Stars</th>
      <th>Hotel Rooms</th>
      <th>Continent</th>
      <th>Membership Years</th>
      <th>Review Month</th>
      <th>Review weekday,</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>USA</td>
      <td>11</td>
      <td>4</td>
      <td>13</td>
      <td>5</td>
      <td>Dec-Feb</td>
      <td>Friends</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>9</td>
      <td>January</td>
      <td>Thursday,</td>
    </tr>
    <tr>
      <th>1</th>
      <td>USA</td>
      <td>119</td>
      <td>21</td>
      <td>75</td>
      <td>3</td>
      <td>Dec-Feb</td>
      <td>Business</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>3</td>
      <td>January</td>
      <td>Friday,</td>
    </tr>
    <tr>
      <th>2</th>
      <td>USA</td>
      <td>36</td>
      <td>9</td>
      <td>25</td>
      <td>5</td>
      <td>Mar-May</td>
      <td>Families</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>2</td>
      <td>February</td>
      <td>Saturday,</td>
    </tr>
    <tr>
      <th>3</th>
      <td>UK</td>
      <td>14</td>
      <td>7</td>
      <td>14</td>
      <td>4</td>
      <td>Mar-May</td>
      <td>Friends</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>Europe</td>
      <td>6</td>
      <td>February</td>
      <td>Friday,</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Canada</td>
      <td>5</td>
      <td>5</td>
      <td>2</td>
      <td>4</td>
      <td>Mar-May</td>
      <td>Solo</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3</td>
      <td>3773</td>
      <td>North America</td>
      <td>7</td>
      <td>March</td>
      <td>Tuesday,</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>499</th>
      <td>UK</td>
      <td>15</td>
      <td>4</td>
      <td>8</td>
      <td>5</td>
      <td>Sep-Nov</td>
      <td>Couples</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>Europe</td>
      <td>1</td>
      <td>October</td>
      <td>Sunday,</td>
    </tr>
    <tr>
      <th>500</th>
      <td>Canada</td>
      <td>50</td>
      <td>13</td>
      <td>29</td>
      <td>4</td>
      <td>Sep-Nov</td>
      <td>Couples</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>8</td>
      <td>November</td>
      <td>Thursday,</td>
    </tr>
    <tr>
      <th>501</th>
      <td>USA</td>
      <td>154</td>
      <td>23</td>
      <td>31</td>
      <td>4</td>
      <td>Sep-Nov</td>
      <td>Friends</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>4</td>
      <td>November</td>
      <td>Thursday,</td>
    </tr>
    <tr>
      <th>502</th>
      <td>USA</td>
      <td>9</td>
      <td>6</td>
      <td>5</td>
      <td>2</td>
      <td>Dec-Feb</td>
      <td>Families</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>9</td>
      <td>December</td>
      <td>Wednesday,</td>
    </tr>
    <tr>
      <th>503</th>
      <td>USA</td>
      <td>20</td>
      <td>19</td>
      <td>112</td>
      <td>4</td>
      <td>Dec-Feb</td>
      <td>Families</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>4</td>
      <td>826</td>
      <td>North America</td>
      <td>5</td>
      <td>December</td>
      <td>Tuesday,</td>
    </tr>
  </tbody>
</table>
<p>504 rows × 20 columns</p>
</div>




```python
lasvegas_data.shape
```




    (504, 20)




```python
lasvegas_data.columns
```




    Index(['Country', 'Total Reviews', 'Hotel Reviews', 'Helpful Votes', 'Rating',
           'Stay Period', 'Traveler Type', 'Has Pool', 'Has Gym',
           'Has Tennis Court', 'Has Spa', 'Has Casino', 'Has Free Internet',
           'Hotel Name', 'Hotel Stars', 'Hotel Rooms', 'Continent',
           'Membership Years', 'Review Month', 'Review weekday,'],
          dtype='object')




```python
lasvegas_data.dtypes
```




    Country              object
    Total Reviews         int64
    Hotel Reviews         int64
    Helpful Votes         int64
    Rating                int64
    Stay Period          object
    Traveler Type        object
    Has Pool             object
    Has Gym              object
    Has Tennis Court     object
    Has Spa              object
    Has Casino            int32
    Has Free Internet    object
    Hotel Name           object
    Hotel Stars          object
    Hotel Rooms           int64
    Continent            object
    Membership Years      int64
    Review Month         object
    Review weekday,      object
    dtype: object




```python
lasvegas_data.isnull()

# no missing values
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>Total Reviews</th>
      <th>Hotel Reviews</th>
      <th>Helpful Votes</th>
      <th>Rating</th>
      <th>Stay Period</th>
      <th>Traveler Type</th>
      <th>Has Pool</th>
      <th>Has Gym</th>
      <th>Has Tennis Court</th>
      <th>Has Spa</th>
      <th>Has Casino</th>
      <th>Has Free Internet</th>
      <th>Hotel Name</th>
      <th>Hotel Stars</th>
      <th>Hotel Rooms</th>
      <th>Continent</th>
      <th>Membership Years</th>
      <th>Review Month</th>
      <th>Review weekday,</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>499</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>500</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>501</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>502</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>503</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>504 rows × 20 columns</p>
</div>




```python
lasvegas_data.describe().astype('int')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Total Reviews</th>
      <th>Hotel Reviews</th>
      <th>Helpful Votes</th>
      <th>Rating</th>
      <th>Has Casino</th>
      <th>Hotel Rooms</th>
      <th>Membership Years</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>504</td>
      <td>504</td>
      <td>504</td>
      <td>504</td>
      <td>504</td>
      <td>504</td>
      <td>504</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>48</td>
      <td>16</td>
      <td>31</td>
      <td>4</td>
      <td>0</td>
      <td>2196</td>
      <td>4</td>
    </tr>
    <tr>
      <th>std</th>
      <td>74</td>
      <td>23</td>
      <td>48</td>
      <td>1</td>
      <td>0</td>
      <td>1285</td>
      <td>2</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>188</td>
      <td>0</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>12</td>
      <td>5</td>
      <td>8</td>
      <td>4</td>
      <td>1</td>
      <td>826</td>
      <td>2</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>23</td>
      <td>9</td>
      <td>16</td>
      <td>4</td>
      <td>1</td>
      <td>2700</td>
      <td>4</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>54</td>
      <td>18</td>
      <td>35</td>
      <td>5</td>
      <td>1</td>
      <td>3025</td>
      <td>6</td>
    </tr>
    <tr>
      <th>max</th>
      <td>775</td>
      <td>263</td>
      <td>365</td>
      <td>5</td>
      <td>1</td>
      <td>4027</td>
      <td>13</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Exploratory Data Analysis - Univariant Analysis

# Number of Hotels as per continent 

count_listing = lasvegas_data['Continent'].value_counts()
count_listing
```




    North America    295
    Europe           118
    Oceania           41
    Asia              36
    Africa             7
    South America      7
    Name: Continent, dtype: int64



### Observation

-- North America has the highest number of hotels listing of about 295 while South America has the lowest number of 7


```python
# visualize using bar chart

ax = count_listing.plot(kind = 'bar',figsize = (10,5),title ='Hotels listing across continents',xlabel='Continent',legend = False)

#annotate
ax.bar_label(ax.containers[0],label_type = 'edge')

#pad the spacing between the number and edge of the figure
ax.margins(y=0.1)

# show the visual
plt.show()
```


    
![png](output_17_0.png)
    



```python
count_listing1 = lasvegas_data['Hotel Name'].value_counts()
count_listing1
```




    Circus Circus Hotel & Casino Las Vegas                 24
    Encore at wynn Las Vegas                               24
    Paris Las Vegas                                        24
    Bellagio Las Vegas                                     24
    The Venetian Las Vegas Hotel                           24
    Wyndham Grand Desert                                   24
    Hilton Grand Vacations at the Flamingo                 24
    Tuscany Las Vegas Suites & Casino                      24
    Marriott's Grand Chateau                               24
    Hilton Grand Vacations on the Boulevard                24
    The Cromwell                                           24
    Excalibur Hotel & Casino                               24
    Trump International Hotel Las Vegas                    24
    Wynn Las Vegas                                         24
    The Palazzo Resort Hotel Casino                        24
    The Cosmopolitan Las Vegas                             24
    Caesars Palace                                         24
    Tropicana Las Vegas - A Double Tree by Hilton Hotel    24
    Treasure Island- TI Hotel & Casino                     24
    Monte Carlo Resort&Casino                              24
    The Westin las Vegas Hotel Casino & Spa                24
    Name: Hotel Name, dtype: int64



### Observation

-- Number of Hotels are same across world of about 24 each


### Bivariate Analysis


```python
lasvegas_data['Has Casino'] = lasvegas_data['Has Casino'].astype(int)
casino_hotel = lasvegas_data.groupby('Hotel Name')['Has Casino'].sum().sort_values()
casino_hotel
```




    Hotel Name
    Hilton Grand Vacations at the Flamingo                  0
    Wyndham Grand Desert                                    0
    Bellagio Las Vegas                                     24
    Tuscany Las Vegas Suites & Casino                      24
    Trump International Hotel Las Vegas                    24
    Tropicana Las Vegas - A Double Tree by Hilton Hotel    24
    Treasure Island- TI Hotel & Casino                     24
    The Westin las Vegas Hotel Casino & Spa                24
    The Venetian Las Vegas Hotel                           24
    The Palazzo Resort Hotel Casino                        24
    The Cromwell                                           24
    The Cosmopolitan Las Vegas                             24
    Monte Carlo Resort&Casino                              24
    Marriott's Grand Chateau                               24
    Hilton Grand Vacations on the Boulevard                24
    Excalibur Hotel & Casino                               24
    Encore at wynn Las Vegas                               24
    Circus Circus Hotel & Casino Las Vegas                 24
    Caesars Palace                                         24
    Paris Las Vegas                                        24
    Wynn Las Vegas                                         24
    Name: Has Casino, dtype: int32




```python
# visualize using bar chart

ax = casino_hotel.plot(kind = 'barh',figsize = (10,5),title ='Hotels with Casino',xlabel='Hotel Name',ylabel = 'Has Casino',legend = False)

#annotate
ax.bar_label(ax.containers[0],label_type = 'edge')

#pad the spacing between the number and edge of the figure
ax.margins(y=0.1)

# show the visual
plt.show()
```


    
![png](output_22_0.png)
    


### Observation

    Almost all hotels having Casino facility except Wyndham Grand Desert and Hilton Grand Vacations at the Flamingo


```python
# viusalise Circus Circus Hotel & Casino Las Vegas Hotels by country

circus_hotels = lasvegas_data[lasvegas_data['Hotel Name'].str.contains('Circus Circus Hotel & Casino Las Vegas', case=False)]
countries = circus_hotels['Country'].unique()
countries
```




    array(['USA', 'UK', 'Canada', 'India', 'Australia', 'New Zeland'],
          dtype=object)




```python
circus_hotels = lasvegas_data[lasvegas_data['Hotel Name'].str.contains('Circus Circus Hotel & Casino Las Vegas', case=False)]
country_counts = circus_hotels.groupby('Country').size().reset_index(name='Number of Hotels')
country_counts
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>Number of Hotels</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Australia</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Canada</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>India</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>New Zeland</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>UK</td>
      <td>5</td>
    </tr>
    <tr>
      <th>5</th>
      <td>USA</td>
      <td>10</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Generateing pie chart for Circus Circus Hotel & Casino Las Vegas hotels by Country
sizes = country_counts['Number of Hotels']
labels = country_counts['Country']

# Plotting the pie chart
explode = (0.1, 0, 0)
plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=90)
plt.axis('equal')

# Title of the pie chart
plt.title('Number of Circus Circus Hotel & Casino Las Vegas Hotels by Country')
plt.show()
```


    
![png](output_26_0.png)
    


### Observation

    More number of Circus Circus Hotel & Casino Las Vegas hotels are located in USA


```python
five_star_hotels = lasvegas_data[lasvegas_data['Rating'] == 5]
hotel_counts = five_star_hotels.groupby('Hotel Name').size().reset_index(name='Count')
hotel_counts = hotel_counts.sort_values('Count', ascending=False)
hotel_counts
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hotel Name</th>
      <th>Count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>20</th>
      <td>Wynn Las Vegas</td>
      <td>18</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Encore at wynn Las Vegas</td>
      <td>17</td>
    </tr>
    <tr>
      <th>13</th>
      <td>The Venetian Las Vegas Hotel</td>
      <td>15</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Trump International Hotel Las Vegas</td>
      <td>15</td>
    </tr>
    <tr>
      <th>10</th>
      <td>The Cosmopolitan Las Vegas</td>
      <td>15</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Marriott's Grand Chateau</td>
      <td>14</td>
    </tr>
    <tr>
      <th>12</th>
      <td>The Palazzo Resort Hotel Casino</td>
      <td>13</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Tuscany Las Vegas Suites &amp; Casino</td>
      <td>13</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Hilton Grand Vacations on the Boulevard</td>
      <td>12</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Caesars Palace</td>
      <td>12</td>
    </tr>
    <tr>
      <th>11</th>
      <td>The Cromwell</td>
      <td>12</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Wyndham Grand Desert</td>
      <td>12</td>
    </tr>
    <tr>
      <th>0</th>
      <td>Bellagio Las Vegas</td>
      <td>12</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Paris Las Vegas</td>
      <td>10</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Hilton Grand Vacations at the Flamingo</td>
      <td>9</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Tropicana Las Vegas - A Double Tree by Hilton ...</td>
      <td>9</td>
    </tr>
    <tr>
      <th>14</th>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>6</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>5</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Excalibur Hotel &amp; Casino</td>
      <td>4</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Monte Carlo Resort&amp;Casino</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
### Top 5 Hotels with rating 5

top = hotel_counts.head(5)
top
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hotel Name</th>
      <th>Count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>20</th>
      <td>Wynn Las Vegas</td>
      <td>18</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Encore at wynn Las Vegas</td>
      <td>17</td>
    </tr>
    <tr>
      <th>13</th>
      <td>The Venetian Las Vegas Hotel</td>
      <td>15</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Trump International Hotel Las Vegas</td>
      <td>15</td>
    </tr>
    <tr>
      <th>10</th>
      <td>The Cosmopolitan Las Vegas</td>
      <td>15</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Set 'Hotel Name' as index
top.set_index('Hotel Name', inplace = True)

# Visualize using bar chart
ax = top.plot(kind='barh', figsize=(10, 5), title='Hotels with Top Rating', xlabel='Count', legend=False)

# Annotate the bar chart
ax.bar_label(ax.containers[0], label_type='edge')

# Pad the spacing between the number and the edge of the figure
ax.margins(y=0.1)

# Show the visualization
plt.show()
```


    
![png](output_30_0.png)
    


### Observation
    Wynn Las Vegas hotel having more number of Hotels with rating top rating 5 while Monte Carlo Resort&Casino and Circus Circus Hotel & Casino Las Vegas having less no of hotels with top rating


```python
### Multivariate Analysis

## Number of Hotels data based on Hotel stars
hotel_counts = lasvegas_data.groupby(['Continent','Hotel Stars']).size().reset_index(name='NumberOfHotels')

# Sort the result by Continent and StarRating
hotel_counts = hotel_counts.sort_values(by=['NumberOfHotels'],ascending=False)

# Print the result
print(hotel_counts)

```

            Continent Hotel Stars  NumberOfHotels
    17  North America           5             107
    15  North America           4              64
    13  North America           3              61
    12         Europe           5              52
    14  North America         3,5              44
    10         Europe           4              29
    8          Europe           3              19
    16  North America         4,5              19
    9          Europe         3,5              15
    7            Asia           5              14
    20        Oceania           4              13
    22        Oceania           5              13
    5            Asia           4              10
    18        Oceania           3               8
    19        Oceania         3,5               6
    4            Asia         3,5               6
    3            Asia           3               5
    26  South America           5               4
    1          Africa           4               3
    11         Europe         4,5               3
    2          Africa           5               2
    0          Africa           3               2
    6            Asia         4,5               1
    21        Oceania         4,5               1
    23  South America           3               1
    24  South America         3,5               1
    25  South America           4               1
    


```python
# Create the pivot table for number of Hotels based on hotel stars
pivot_table = hotel_counts.pivot_table(index='Continent', columns='Hotel Stars', values='NumberOfHotels', aggfunc='sum')

pivot_table.plot.bar(figsize=(20,5))
plt.ticklabel_format(style = 'plain', axis ='y')
plt.show()
```


    
![png](output_33_0.png)
    


### Observation

    Most of the Top star hotels are located in North America


```python
# Filter the DataFrame for 'Wynn Las Vegas' hotel
wynn_data = lasvegas_data[lasvegas_data['Hotel Name'] == 'Wynn Las Vegas']

# Group by 'Travellertype' and count occurrences
grouped_data = wynn_data['Traveler Type'].value_counts()

# Create a pie chart
plt.pie(grouped_data, labels=grouped_data.index, autopct='%1.1f%%')
plt.title("Travellertype Distribution for Wynn Las Vegas")
plt.axis('equal')  # Equal aspect ratio ensures a circular pie chart
plt.show()
```


    
![png](output_35_0.png)
    


#### Observation

    Most or the traveler type are Couples for the Top rated Hotel Wynn Las Vegas and less number of families 


```python
# Group by 'Rating' and count the number of hotels
grouped_data = lasvegas_data.groupby('Traveler Type')['Hotel Name'].count()
grouped_data
```




    Traveler Type
    Business     74
    Couples     214
    Families    110
    Friends      82
    Solo         24
    Name: Hotel Name, dtype: int64




```python
# Calculate the explode values
explode = [0.1] * len(grouped_data)  # Set the same explode value for all wedges

# Plot the pie chart
plt.pie(grouped_data, labels=grouped_data.index, autopct='%1.2f%%', pctdistance=0.85, explode=explode)

# draw a circle
centre_circle = plt.Circle((0,0),0.7,fc='white')
fig = plt.gcf()

#adding circle
fig.gca().add_artist(centre_circle)

#adding title
plt.title('classification based on Traveler Type')

#show the chart
plt.show()
```


    
![png](output_38_0.png)
    


#### Observation

Most of the Traveler Type visiting Hotels are Couples while solo Traveler type are visting in least number


```python
hotel_reviews = lasvegas_data.groupby('Hotel Name')[['Total Reviews', 'Helpful Votes']].sum()
hotel_reviews
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Total Reviews</th>
      <th>Helpful Votes</th>
    </tr>
    <tr>
      <th>Hotel Name</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Bellagio Las Vegas</th>
      <td>665</td>
      <td>597</td>
    </tr>
    <tr>
      <th>Caesars Palace</th>
      <td>912</td>
      <td>633</td>
    </tr>
    <tr>
      <th>Circus Circus Hotel &amp; Casino Las Vegas</th>
      <td>701</td>
      <td>444</td>
    </tr>
    <tr>
      <th>Encore at wynn Las Vegas</th>
      <td>1372</td>
      <td>882</td>
    </tr>
    <tr>
      <th>Excalibur Hotel &amp; Casino</th>
      <td>1094</td>
      <td>762</td>
    </tr>
    <tr>
      <th>Hilton Grand Vacations at the Flamingo</th>
      <td>1162</td>
      <td>779</td>
    </tr>
    <tr>
      <th>Hilton Grand Vacations on the Boulevard</th>
      <td>886</td>
      <td>500</td>
    </tr>
    <tr>
      <th>Marriott's Grand Chateau</th>
      <td>2161</td>
      <td>1376</td>
    </tr>
    <tr>
      <th>Monte Carlo Resort&amp;Casino</th>
      <td>1724</td>
      <td>942</td>
    </tr>
    <tr>
      <th>Paris Las Vegas</th>
      <td>1229</td>
      <td>644</td>
    </tr>
    <tr>
      <th>The Cosmopolitan Las Vegas</th>
      <td>811</td>
      <td>685</td>
    </tr>
    <tr>
      <th>The Cromwell</th>
      <td>1717</td>
      <td>1084</td>
    </tr>
    <tr>
      <th>The Palazzo Resort Hotel Casino</th>
      <td>1078</td>
      <td>753</td>
    </tr>
    <tr>
      <th>The Venetian Las Vegas Hotel</th>
      <td>769</td>
      <td>576</td>
    </tr>
    <tr>
      <th>The Westin las Vegas Hotel Casino &amp; Spa</th>
      <td>1115</td>
      <td>868</td>
    </tr>
    <tr>
      <th>Treasure Island- TI Hotel &amp; Casino</th>
      <td>577</td>
      <td>493</td>
    </tr>
    <tr>
      <th>Tropicana Las Vegas - A Double Tree by Hilton Hotel</th>
      <td>732</td>
      <td>546</td>
    </tr>
    <tr>
      <th>Trump International Hotel Las Vegas</th>
      <td>1560</td>
      <td>667</td>
    </tr>
    <tr>
      <th>Tuscany Las Vegas Suites &amp; Casino</th>
      <td>1538</td>
      <td>955</td>
    </tr>
    <tr>
      <th>Wyndham Grand Desert</th>
      <td>1604</td>
      <td>898</td>
    </tr>
    <tr>
      <th>Wynn Las Vegas</th>
      <td>851</td>
      <td>919</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Set the position of the bars on the x-axis
x = np.arange(len(hotel_reviews))

# Set the width of the bars
bar_width = 0.35

# Create a grouped bar chart
plt.figure(figsize=(20, 8))
plt.bar(x - bar_width/2, hotel_reviews['Total Reviews'], width=bar_width, label='Total Reviews')
plt.bar(x + bar_width/2, hotel_reviews['Helpful Votes'], width=bar_width, label='Helpful Votes')

# Add labels and title
plt.xlabel('Hotel Name')
plt.title('Total Reviews and Helpful Votes by Hotel')
plt.xticks(x, hotel_reviews.index, rotation=45)

# Add a legend
plt.legend()

# Display the chart
plt.tight_layout()
plt.show()

```


    
![png](output_41_0.png)
    


### Observation

Hilton Grand Vacations on the Boulevard Hotel having more reviews and more number of helpful Votes


```python
hotel_rooms = lasvegas_data[['Hotel Name', 'Hotel Rooms']].drop_duplicates()
hotel_rooms_sorted = hotel_rooms.sort_values('Hotel Rooms', ascending=False)
hotel_rooms_sorted
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hotel Name</th>
      <th>Hotel Rooms</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>408</th>
      <td>The Venetian Las Vegas Hotel</td>
      <td>4027</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Excalibur Hotel &amp; Casino</td>
      <td>3981</td>
    </tr>
    <tr>
      <th>432</th>
      <td>Bellagio Las Vegas</td>
      <td>3933</td>
    </tr>
    <tr>
      <th>0</th>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3773</td>
    </tr>
    <tr>
      <th>120</th>
      <td>Caesars Palace</td>
      <td>3348</td>
    </tr>
    <tr>
      <th>168</th>
      <td>The Palazzo Resort Hotel Casino</td>
      <td>3025</td>
    </tr>
    <tr>
      <th>48</th>
      <td>Monte Carlo Resort&amp;Casino</td>
      <td>3003</td>
    </tr>
    <tr>
      <th>144</th>
      <td>The Cosmopolitan Las Vegas</td>
      <td>2959</td>
    </tr>
    <tr>
      <th>456</th>
      <td>Paris Las Vegas</td>
      <td>2916</td>
    </tr>
    <tr>
      <th>72</th>
      <td>Treasure Island- TI Hotel &amp; Casino</td>
      <td>2884</td>
    </tr>
    <tr>
      <th>192</th>
      <td>Wynn Las Vegas</td>
      <td>2700</td>
    </tr>
    <tr>
      <th>264</th>
      <td>Encore at wynn Las Vegas</td>
      <td>2034</td>
    </tr>
    <tr>
      <th>96</th>
      <td>Tropicana Las Vegas - A Double Tree by Hilton ...</td>
      <td>1467</td>
    </tr>
    <tr>
      <th>216</th>
      <td>Trump International Hotel Las Vegas</td>
      <td>1282</td>
    </tr>
    <tr>
      <th>288</th>
      <td>Hilton Grand Vacations on the Boulevard</td>
      <td>1228</td>
    </tr>
    <tr>
      <th>480</th>
      <td>The Westin las Vegas Hotel Casino &amp; Spa</td>
      <td>826</td>
    </tr>
    <tr>
      <th>384</th>
      <td>Wyndham Grand Desert</td>
      <td>787</td>
    </tr>
    <tr>
      <th>312</th>
      <td>Marriott's Grand Chateau</td>
      <td>732</td>
    </tr>
    <tr>
      <th>336</th>
      <td>Tuscany Las Vegas Suites &amp; Casino</td>
      <td>716</td>
    </tr>
    <tr>
      <th>360</th>
      <td>Hilton Grand Vacations at the Flamingo</td>
      <td>315</td>
    </tr>
    <tr>
      <th>240</th>
      <td>The Cromwell</td>
      <td>188</td>
    </tr>
  </tbody>
</table>
</div>




```python
top_hotel_rooms = hotel_rooms_sorted.head()
top_hotel_rooms
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hotel Name</th>
      <th>Hotel Rooms</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>408</th>
      <td>The Venetian Las Vegas Hotel</td>
      <td>4027</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Excalibur Hotel &amp; Casino</td>
      <td>3981</td>
    </tr>
    <tr>
      <th>432</th>
      <td>Bellagio Las Vegas</td>
      <td>3933</td>
    </tr>
    <tr>
      <th>0</th>
      <td>Circus Circus Hotel &amp; Casino Las Vegas</td>
      <td>3773</td>
    </tr>
    <tr>
      <th>120</th>
      <td>Caesars Palace</td>
      <td>3348</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Sort the hotel rooms by descending order
top_hotel_rooms = top_hotel_rooms.sort_values('Hotel Rooms', ascending=False)

# Get the hotel names and room counts
hotel_names = top_hotel_rooms['Hotel Name']
room_counts = top_hotel_rooms['Hotel Rooms']

# Create a bar chart
plt.figure(figsize=(10, 6))
bar_width = 0.5
bars = plt.bar(hotel_names, room_counts, width=bar_width)

# Add labels and title
plt.title('Distribution of Hotel Rooms')

# Rotate x-axis labels if needed
plt.xticks(rotation=45, ha='right')

# Add count values on top of each bar
for bar in bars:
    height = bar.get_height()
    plt.text(bar.get_x() + bar.get_width() / 2, height, str(height), ha='center', va='bottom')

# Display the chart
plt.tight_layout()
plt.show()
```


    
![png](output_45_0.png)
    


### Observation

The Venetian Las Vegas Hotel having the more number of rooms compared to all hotels


```python

```
